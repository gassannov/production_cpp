//
// Created by Марат Гасанов on 31.10.2022.
//
#include "excel_format.h"
#include "iostream"

int main(){
    std::cout << "foo" << std::endl;
}
